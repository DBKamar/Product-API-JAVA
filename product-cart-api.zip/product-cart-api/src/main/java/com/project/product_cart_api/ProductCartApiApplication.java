package com.project.product_cart_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartApiApplication.class, args);
	}

}
